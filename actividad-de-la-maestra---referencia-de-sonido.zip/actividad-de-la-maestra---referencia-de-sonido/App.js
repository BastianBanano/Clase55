import * as React from 'react';
import { Text, View, Button, TouchableOpacity } from 'react-native';
import {Audio} from 'expo-av'


class SoundButton extends React.Component {
   playSound = async () => {
  }

  render() {
    return (
      <TouchableOpacity style = {{
        marginLeft:100,
        borderWidth:1,
        borderColor:'green',
        alignItems:"center",
        justifyContent:"center",
        width:200,
        height:200,
        backgroundColor:"purple",
        borderRadius:100,
      }}>

      <Text style = {{
        fontWeight:"bold",
        fontSize:20
        }}>Presioname</Text>
      </TouchableOpacity>
    );
  }
}

export default class App extends React.Component {
  render() {
    return (
      <View style={{marginTop:200}}>
        <SoundButton />
      </View>
    );
  }
}

